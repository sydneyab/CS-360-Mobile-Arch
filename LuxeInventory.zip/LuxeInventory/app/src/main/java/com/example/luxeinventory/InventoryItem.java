package com.example.luxeinventory;

/**
 * Simple model for one row in the inventory table (a handbag or accessory).
 */
public class InventoryItem {

    // At or below this quantity, an item counts as low stock and triggers an SMS alert
    public static final int LOW_STOCK_THRESHOLD = 5;

    private final long id;
    private final String name;
    private final String brand;
    private final int quantity;

    public InventoryItem(long id, String name, String brand, int quantity) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }

    public int getQuantity() {
        return quantity;
    }

    /** Returns true when the quantity has dropped to the low stock level or below. */
    public boolean isLowStock() {
        return quantity <= LOW_STOCK_THRESHOLD;
    }
}
