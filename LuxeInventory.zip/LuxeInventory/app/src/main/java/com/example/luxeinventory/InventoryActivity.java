package com.example.luxeinventory;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Main screen after login. Shows every inventory item in a grid and lets the user
 * add, edit, and delete items. Also asks for SMS permission and sends low stock texts.
 */
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.ItemActionListener {

    public static final String EXTRA_USERNAME = "extra_username";

    private static final int GRID_COLUMNS = 2;

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private TextView emptyText;
    private String userPhone;

    // Handles the answer from Android's "Allow SMS?" system dialog
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(this, R.string.sms_granted, Toast.LENGTH_SHORT).show();
                } else {
                    // Denied: the app keeps working, it just will not send texts
                    Toast.makeText(this, R.string.sms_denied, Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        // Look up the logged in user's phone number for text alerts
        String username = getIntent().getStringExtra(EXTRA_USERNAME);
        userPhone = databaseHelper.getPhone(username);

        TextView welcomeText = findViewById(R.id.textWelcome);
        welcomeText.setText(getString(R.string.welcome_user, username));
        emptyText = findViewById(R.id.textEmpty);

        // Set up the grid
        RecyclerView grid = findViewById(R.id.recyclerInventory);
        grid.setLayoutManager(new GridLayoutManager(this, GRID_COLUMNS));
        adapter = new InventoryAdapter(this);
        grid.setAdapter(adapter);

        findViewById(R.id.buttonAddItem).setOnClickListener(v -> showItemDialog(null));
        findViewById(R.id.buttonLogout).setOnClickListener(v -> logOut());

        refreshGrid();
        askForSmsPermissionIfNeeded();
    }

    // ---------------------------------------------------------------
    // Grid
    // ---------------------------------------------------------------

    /** Reloads all items from the database and updates the grid. */
    private void refreshGrid() {
        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter.setItems(items);
        emptyText.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onEditClicked(InventoryItem item) {
        showItemDialog(item);
    }

    @Override
    public void onDeleteClicked(InventoryItem item) {
        // Ask first so an accidental tap does not wipe an item
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_title)
                .setMessage(getString(R.string.delete_message, item.getName()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    databaseHelper.deleteItem(item.getId());
                    refreshGrid();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ---------------------------------------------------------------
    // Add and edit dialog
    // ---------------------------------------------------------------

    /** Shows the item form. Pass null to add a new item, or an item to edit it. */
    private void showItemDialog(InventoryItem existingItem) {
        View form = LayoutInflater.from(this).inflate(R.layout.dialog_item, null);
        EditText nameInput = form.findViewById(R.id.editItemName);
        EditText brandInput = form.findViewById(R.id.editItemBrand);
        EditText quantityInput = form.findViewById(R.id.editItemQuantity);

        // When editing, fill the form with the current values
        if (existingItem != null) {
            nameInput.setText(existingItem.getName());
            brandInput.setText(existingItem.getBrand());
            quantityInput.setText(String.valueOf(existingItem.getQuantity()));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existingItem == null ? R.string.add_item_title : R.string.edit_item_title)
                .setView(form)
                .setPositiveButton(R.string.save, null) // set below so bad input keeps the dialog open
                .setNegativeButton(R.string.cancel, null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(v -> {
                    if (saveItem(existingItem, nameInput, brandInput, quantityInput)) {
                        dialog.dismiss();
                    }
                }));
        dialog.show();
    }

    /**
     * Validates the form and saves it. Returns true when the item was saved,
     * false when the input needs fixing (the dialog stays open).
     */
    private boolean saveItem(InventoryItem existingItem, EditText nameInput,
                             EditText brandInput, EditText quantityInput) {
        String name = nameInput.getText().toString().trim();
        String brand = brandInput.getText().toString().trim();
        String quantityText = quantityInput.getText().toString().trim();

        if (name.isEmpty()) {
            nameInput.setError(getString(R.string.error_name_required));
            return false;
        }
        if (brand.isEmpty()) {
            brandInput.setError(getString(R.string.error_brand_required));
            return false;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            quantityInput.setError(getString(R.string.error_quantity_invalid));
            return false;
        }
        if (quantity < 0) {
            quantityInput.setError(getString(R.string.error_quantity_invalid));
            return false;
        }

        long itemId;
        if (existingItem == null) {
            itemId = databaseHelper.addItem(name, brand, quantity);   // Create
        } else {
            databaseHelper.updateItem(existingItem.getId(), name, brand, quantity); // Update
            itemId = existingItem.getId();
        }

        refreshGrid();
        sendLowStockAlertIfNeeded(new InventoryItem(itemId, name, brand, quantity));
        return true;
    }

    // ---------------------------------------------------------------
    // SMS permission and alerts
    // ---------------------------------------------------------------

    /** Explains why SMS is needed, then shows Android's permission dialog if the user agrees. */
    private void askForSmsPermissionIfNeeded() {
        if (SmsHelper.hasSmsPermission(this)) {
            return; // already allowed
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.sms_prompt_title)
                .setMessage(R.string.sms_prompt_message)
                .setPositiveButton(R.string.allow, (dialog, which) ->
                        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS))
                .setNegativeButton(R.string.not_now, (dialog, which) ->
                        Toast.makeText(this, R.string.sms_denied, Toast.LENGTH_LONG).show())
                .show();
    }

    /** Sends a text if the item is low on stock. Does nothing special when SMS is off. */
    private void sendLowStockAlertIfNeeded(InventoryItem item) {
        if (!item.isLowStock()) {
            return;
        }
        if (SmsHelper.sendLowStockAlert(this, userPhone, item)) {
            Toast.makeText(this, R.string.sms_sent, Toast.LENGTH_SHORT).show();
        } else {
            // Permission denied or no number: tell the user, but keep the app running
            Toast.makeText(this, R.string.low_stock_no_sms, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------
    // Logout
    // ---------------------------------------------------------------

    /** Returns to the login screen and clears this screen from the back stack. */
    private void logOut() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
