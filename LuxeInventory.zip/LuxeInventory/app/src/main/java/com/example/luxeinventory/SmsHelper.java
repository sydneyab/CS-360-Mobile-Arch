package com.example.luxeinventory;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

/**
 * Sends the low stock text message. Every method checks permission first,
 * so if the user said no, nothing breaks and the rest of the app keeps working.
 */
public final class SmsHelper {

    private SmsHelper() {
        // Utility class, no instances needed
    }

    /** Returns true if the user has allowed the app to send SMS messages. */
    public static boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Texts the user that an item is running low.
     * Returns true if the message was handed off to the phone, false if it was skipped or failed.
     */
    @SuppressWarnings("deprecation") // SmsManager.getDefault() is only used on Android 11 and older
    public static boolean sendLowStockAlert(Context context, String phoneNumber, InventoryItem item) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty() || !hasSmsPermission(context)) {
            return false; // no number saved, or permission denied
        }

        String message = "Luxe Inventory alert: " + item.getBrand() + " " + item.getName()
                + " is low on stock. Only " + item.getQuantity() + " left.";

        try {
            SmsManager smsManager;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsManager = context.getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (IllegalArgumentException | SecurityException | NullPointerException e) {
            // Bad phone number, permission revoked mid-send, or a device with no SMS support
            return false;
        }
    }
}
