package com.example.luxeinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles every SQLite operation for the app.
 * Two tables: users (login accounts) and inventory_items (the grid data).
 * The database file lives in app storage, so data stays saved when the app closes.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "luxe_inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";
    private static final String COL_PHONE = "phone";

    // Inventory table
    private static final String TABLE_ITEMS = "inventory_items";
    private static final String COL_ITEM_ID = "id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_BRAND = "brand";
    private static final String COL_ITEM_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Usernames are unique and not case sensitive ("Syd" and "syd" are the same account)
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_PHONE + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_ITEM_BRAND + " TEXT NOT NULL, "
                + COL_ITEM_QUANTITY + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No migrations needed yet, so rebuild the tables if the version ever changes
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ---------------------------------------------------------------
    // User accounts
    // ---------------------------------------------------------------

    /** Returns true if an account with this username already exists. */
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Saves a new account. The password is never stored as plain text,
     * only a salted SHA-256 hash of it. Returns false if the username is taken.
     */
    public boolean createUser(String username, String password, String phone) {
        if (usernameExists(username)) {
            return false;
        }
        String salt = generateSalt();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_SALT, salt);
        values.put(COL_PASSWORD_HASH, hashPassword(salt, password));
        values.put(COL_PHONE, phone);

        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** Checks a username and password against the saved account. */
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{COL_SALT, COL_PASSWORD_HASH},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            if (!cursor.moveToFirst()) {
                return false; // no account with that username
            }
            String salt = cursor.getString(0);
            String savedHash = cursor.getString(1);
            // Hash what the user typed with the saved salt and compare the results
            return MessageDigest.isEqual(
                    hashPassword(salt, password).getBytes(StandardCharsets.UTF_8),
                    savedHash.getBytes(StandardCharsets.UTF_8));
        }
    }

    /** Returns the phone number saved for this user, or an empty string if not found. */
    public String getPhone(String username) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS, new String[]{COL_PHONE},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : "";
        }
    }

    // ---------------------------------------------------------------
    // Inventory: create, read, update, delete
    // ---------------------------------------------------------------

    /** Create: adds a new item and returns its new row id (or -1 on failure). */
    public long addItem(String name, String brand, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_BRAND, brand);
        values.put(COL_ITEM_QUANTITY, quantity);
        return getWritableDatabase().insert(TABLE_ITEMS, null, values);
    }

    /** Read: returns every item, sorted by name, for the grid. */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_BRAND, COL_ITEM_QUANTITY},
                null, null, null, null, COL_ITEM_NAME + " COLLATE NOCASE")) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(
                        cursor.getLong(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getInt(3)));
            }
        }
        return items;
    }

    /** Update: changes the name, brand, and quantity of one item. Returns rows changed. */
    public int updateItem(long id, String name, String brand, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_BRAND, brand);
        values.put(COL_ITEM_QUANTITY, quantity);
        return getWritableDatabase().update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    /** Delete: removes one item by its id. Returns rows removed. */
    public int deleteItem(long id) {
        return getWritableDatabase().delete(TABLE_ITEMS,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(id)});
    }

    // ---------------------------------------------------------------
    // Password helpers
    // ---------------------------------------------------------------

    /** Makes a random salt so two users with the same password get different hashes. */
    private String generateSalt() {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        return Base64.encodeToString(saltBytes, Base64.NO_WRAP);
    }

    /** Returns a Base64 SHA-256 hash of the salt plus the password. */
    private String hashPassword(String salt, String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest((salt + password).getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(hashBytes, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is built into every Android version, so this should never happen
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
