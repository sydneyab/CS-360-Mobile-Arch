package com.example.luxeinventory;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * First screen of the app. One form that switches between two modes:
 * log in (returning users) and create account (first time users).
 */
public class LoginActivity extends AppCompatActivity {

    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MIN_PASSWORD_LENGTH = 6;

    private DatabaseHelper databaseHelper;

    private TextView headingText;
    private TextView switchModeText;
    private EditText usernameInput;
    private EditText passwordInput;
    private EditText phoneInput;
    private Button submitButton;

    // true = showing the create account form, false = showing the login form
    private boolean isCreateMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        headingText = findViewById(R.id.textHeading);
        switchModeText = findViewById(R.id.textSwitchMode);
        usernameInput = findViewById(R.id.editUsername);
        passwordInput = findViewById(R.id.editPassword);
        phoneInput = findViewById(R.id.editPhone);
        submitButton = findViewById(R.id.buttonSubmit);

        switchModeText.setOnClickListener(v -> setMode(!isCreateMode));
        submitButton.setOnClickListener(v -> {
            if (isCreateMode) {
                handleCreateAccount();
            } else {
                handleLogin();
            }
        });

        setMode(false); // start on the login form
    }

    /** Updates the labels and shows or hides the phone field for the chosen mode. */
    private void setMode(boolean createMode) {
        isCreateMode = createMode;
        headingText.setText(createMode ? R.string.heading_create : R.string.heading_login);
        submitButton.setText(createMode ? R.string.button_create : R.string.button_login);
        switchModeText.setText(createMode ? R.string.switch_to_login : R.string.switch_to_create);
        phoneInput.setVisibility(createMode ? View.VISIBLE : View.GONE);
    }

    /** Checks the typed username and password against the database. */
    private void handleLogin() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, R.string.error_fill_fields, Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.validateLogin(username, password)) {
            openInventory(username);
        } else {
            Toast.makeText(this, R.string.error_bad_login, Toast.LENGTH_SHORT).show();
        }
    }

    /** Validates the form, saves the new account, then logs the user straight in. */
    private void handleCreateAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();
        String phone = phoneInput.getText().toString().trim();

        if (username.length() < MIN_USERNAME_LENGTH) {
            usernameInput.setError(getString(R.string.error_username_short, MIN_USERNAME_LENGTH));
            return;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            passwordInput.setError(getString(R.string.error_password_short, MIN_PASSWORD_LENGTH));
            return;
        }
        // Patterns.PHONE is loose on purpose so short emulator numbers like 5554 still work
        if (!Patterns.PHONE.matcher(phone).matches()) {
            phoneInput.setError(getString(R.string.error_phone_invalid));
            return;
        }
        if (databaseHelper.usernameExists(username)) {
            usernameInput.setError(getString(R.string.error_username_taken));
            return;
        }

        if (databaseHelper.createUser(username, password, phone)) {
            Toast.makeText(this, R.string.message_account_created, Toast.LENGTH_SHORT).show();
            openInventory(username);
        } else {
            Toast.makeText(this, R.string.error_create_failed, Toast.LENGTH_SHORT).show();
        }
    }

    /** Moves on to the inventory screen and closes the login screen. */
    private void openInventory(String username) {
        Intent intent = new Intent(this, InventoryActivity.class);
        intent.putExtra(InventoryActivity.EXTRA_USERNAME, username);
        startActivity(intent);
        finish();
    }
}
