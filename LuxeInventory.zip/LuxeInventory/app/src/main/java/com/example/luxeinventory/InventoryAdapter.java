package com.example.luxeinventory;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Feeds inventory items into the RecyclerView grid.
 * Each cell shows one item with Edit and Delete buttons.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    /** Lets the activity react when a button inside a grid cell is tapped. */
    public interface ItemActionListener {
        void onEditClicked(InventoryItem item);

        void onDeleteClicked(InventoryItem item);
    }

    private final List<InventoryItem> items = new ArrayList<>();
    private final ItemActionListener listener;

    public InventoryAdapter(ItemActionListener listener) {
        this.listener = listener;
    }

    /** Replaces everything in the grid with a fresh list from the database. */
    public void setItems(List<InventoryItem> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View cell = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ItemViewHolder(cell);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.nameText.setText(item.getName());
        holder.brandText.setText(item.getBrand());
        holder.quantityText.setText(holder.itemView.getContext()
                .getString(R.string.quantity_label, item.getQuantity()));

        // Only show the LOW STOCK tag when the quantity is at or below the threshold
        holder.lowStockText.setVisibility(item.isLowStock() ? View.VISIBLE : View.GONE);

        holder.editButton.setOnClickListener(v -> listener.onEditClicked(item));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClicked(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    /** Holds the views for one grid cell so they are only looked up once. */
    static class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView nameText;
        final TextView brandText;
        final TextView quantityText;
        final TextView lowStockText;
        final Button editButton;
        final Button deleteButton;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.textItemName);
            brandText = itemView.findViewById(R.id.textItemBrand);
            quantityText = itemView.findViewById(R.id.textItemQuantity);
            lowStockText = itemView.findViewById(R.id.textLowStock);
            editButton = itemView.findViewById(R.id.buttonEditItem);
            deleteButton = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
